from django.shortcuts import render, get_object_or_404,redirect
from .models import Chat,Message
import json
from django.db.models import Q
from django.db.models import Q, OuterRef, Subquery
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count, OuterRef, Subquery

# ! CHAT VIEW

@login_required(login_url='/accounts/signin')
def ChatUsers(request, chat_id):

    # * User approval for chat access

    user = request.user
    user_one = Chat.objects.get(id = chat_id).user_one.id
    user_two = Chat.objects.get(id = chat_id).user_two.id

    if user.id == user_one or user.id == user_two:
        print("verify")
    else:
        return redirect('/accounts/profile')
    
    # * Checking the presence of chat

    chat = get_object_or_404(Chat, id=chat_id)
    messages_queryset = Message.objects.filter(chat__id=chat_id).order_by('timestamp')

    message_list = [
        {
            'id': msg.id,
            'sender_username': msg.user.username,
            'message': msg.message,
            'seen': msg.seen,
            'timestamp': msg.timestamp.isoformat()
        } for msg in messages_queryset
    ]

    json_string = json.dumps(message_list)

    print(json_string)

    context = {'chat_id': chat.id,'messages':json_string}
    return render(request, 'profile/chat-test.html', context)


# ! CHATS VIEW

@login_required(login_url='/accounts/signin')
def ChatsUser(request):
    user = request.user

    latest_message_subquery = Message.objects.filter(
        chat=OuterRef('pk')
    ).order_by('-timestamp')

    chats_query = Chat.objects.filter(
        Q(user_one=user) | Q(user_two=user)
    ).annotate(
        last_message_text=Subquery(
            latest_message_subquery.values('message')[:1]
        ),
        latest_message_time=Subquery(
            latest_message_subquery.values('timestamp')[:1]
        ),
        last_message_sender_id=Subquery(
            latest_message_subquery.values('user__id')[:1]
        ),
        unread_count=Count(
            'message',
            filter=Q(message__seen=False) & ~Q(message__user=user)
        )
    ).order_by('-id')

    context = {
        "chats": chats_query
    }

    return render(request, 'profile/my-chats.html', context)