from django.db import models
from user_account.models import CustomUser

# Create your models here.


# ! CHAT MODEL

class Chat(models.Model):
    user_one = models.ForeignKey(CustomUser,verbose_name='user one',on_delete=models.CASCADE,related_name='chats_as_one')
    user_two = models.ForeignKey(CustomUser,verbose_name='user two',on_delete=models.CASCADE,related_name='chats_as_two')

    def __str__(self):
        return f"chat {self.id}"
    
    class Meta:
        verbose_name="users chat"
        verbose_name_plural="chats"
    

class Message(models.Model):
    chat = models.ForeignKey(Chat,verbose_name='chat',on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser,verbose_name='user sender',on_delete=models.CASCADE)
    message = models.TextField(verbose_name='message')
    file_message = models.FileField(verbose_name='file',null=True,blank=True)
    seen = models.BooleanField(default=False, verbose_name='seen')
    timestamp = models.DateTimeField(auto_now_add=True, null=True, verbose_name='timestamp') 
    

    def __str__(self):
        return (self.message)
    
    class Meta:
        verbose_name='message'
        verbose_name_plural="messages"