import json
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async
from django.db.models import Q

from chat.models import Chat, Message
from user_account.models import CustomUser


class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for real-time chat.
    Features:
    - send messages
    - seen status (real-time)
    - chat membership verification
    """

    # ------------------------
    # Connection
    # ------------------------
    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated:
            await self.close()
            return

        self.chat_id = self.scope["url_route"]["kwargs"]["chat_id"]
        self.room_name = f"chat_{self.chat_id}"

        # Check if user belongs to chat
        is_member = await self.is_user_chat_member()
        if not is_member:
            await self.close()
            return

        # Join group
        await self.channel_layer.group_add(self.room_name, self.channel_name)
        await self.accept()
        print(f"✅ {self.user.username} connected to chat {self.chat_id}")

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_name, self.channel_name)
        print(f"❎ {self.user.username} disconnected from chat {self.chat_id}")

    # ------------------------
    # Receive from WebSocket
    # ------------------------
    async def receive(self, text_data):
        data = json.loads(text_data)
        action = data.get("action")

        if action == "send":
            await self.handle_send_message(data)
        elif action == "seen":
            await self.mark_message_seen(data.get("msg_id"))
        elif action == "seen_all":
            await self.mark_all_messages_seen()

    # ------------------------
    # Group events
    # ------------------------
    async def chat_message(self, event):
        """Send new message to clients (including sender replacement of temp_id)"""
        await self.send(text_data=json.dumps({
            "action": "new_message",
            "message": event["message"],
            "username": event["username"],
            "msg_id": event["msg_id"],
            "timestamp": event.get("timestamp"),
            "temp_id": event.get("temp_id"),
        }))

    async def message_seen(self, event):
        """Notify clients that message is seen"""
        await self.send(text_data=json.dumps({
            "action": "seen_update",
            "msg_id": event["msg_id"],
        }))

    # ------------------------
    # Message handling
    # ------------------------
    async def handle_send_message(self, data):
        message_text = data.get("message")
        temp_id = data.get("temp_id")
        timestamp = data.get("timestamp")

        if not message_text:
            return

        msg_id = await self.save_message_to_db(message_text)

        if msg_id:
            await self.channel_layer.group_send(
                self.room_name,
                {
                    "type": "chat_message",
                    "message": message_text,
                    "username": self.user.username,
                    "msg_id": msg_id,
                    "timestamp": timestamp,
                    "sender_channel": self.channel_name,
                    "temp_id": temp_id
                }
            )

    # ------------------------
    # Seen logic
    # ------------------------
    async def mark_message_seen(self, msg_id):
        if not msg_id:
            return
        try:
            msg = await sync_to_async(Message.objects.get)(id=msg_id)
            if not msg.seen:
                msg.seen = True
                await sync_to_async(msg.save)()

            # Notify all clients (including sender)
            await self.channel_layer.group_send(
                f"chat_{msg.chat_id}",
                {
                    "type": "message_seen",
                    "msg_id": msg.id,
                }
            )
        except Message.DoesNotExist:
            pass

    async def mark_all_messages_seen(self):
        unseen_messages = await sync_to_async(list)(
            Message.objects.filter(chat_id=self.chat_id, seen=False).exclude(user=self.user)
        )
        for msg in unseen_messages:
            msg.seen = True
            await sync_to_async(msg.save)()
            await self.channel_layer.group_send(
                f"chat_{msg.chat_id}",
                {"type": "message_seen", "msg_id": msg.id}
            )
        print(f"👁 {len(unseen_messages)} messages marked as seen")

    # ------------------------
    # DB helpers
    # ------------------------
    @sync_to_async
    def is_user_chat_member(self):
        return Chat.objects.filter(
            id=self.chat_id
        ).filter(Q(user_one=self.user) | Q(user_two=self.user)).exists()

    @sync_to_async
    def save_message_to_db(self, message_text):
        chat = Chat.objects.get(id=self.chat_id)
        msg = Message.objects.create(chat=chat, user=self.user, message=message_text)
        print(f"💾 Message saved (id={msg.id}) by {self.user.username}")
        return msg.id
