from django.urls import path
from .views import ChatUsers,ChatsUser

urlpatterns = [
    path('accounts/chat/<int:chat_id>/', ChatUsers, name='chat_page'),
    path('accounts/my-chats', ChatsUser, name='chats_page'),

]
