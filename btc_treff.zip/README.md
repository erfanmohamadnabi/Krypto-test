# Crypto Exchange Platform (Germany)

A web-based platform for in-person cryptocurrency trading in Germany.
The system connects buyers and sellers directly and provides secure,
real-time communication.

---

## Project Overview
This platform allows users to publish cryptocurrency buy/sell advertisements
and arrange in-person trades.
A real-time chat system enables direct communication between buyers and sellers
using WebSocket technology.

---

## Technologies Used

### Front-end
- JavaScript (Vanilla)
- Tailwind CSS
- AJAX

### Back-end
- Django
- Django Channels
- WebSocket (Real-time communication)

---

## Features
- Create and browse cryptocurrency buy/sell advertisements
- Real-time chat using WebSocket
- Instant message delivery without page refresh
- Dynamic data loading with AJAX
- Responsive design for mobile and desktop
- Image compression and conversion to WebP for faster loading


---

## Developer / Author
**Erfan MOhammadnabi**  
Email: erfan.web8787@gmail.com  
GitHub: [erfanmohamadnabi](https://github.com/erfanmohamadnabi)

---

## How to Run the Project
1. Clone the repository
2. Install backend dependencies
3. Run the Django development server
4. Access the platform via browser

---

## Project Structure
```text
├── manage.py
├── README.md
├── frontend/
│   ├── js/
│   └── styles/
├── backend/
│   ├── apps/
│   └── channels/
