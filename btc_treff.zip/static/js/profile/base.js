

// ! TRANSLATE JS PROFILE PAGE

const translations = {

    // * PROFILE PAGE TRANSLATION DICTIONARY

    de: {
        settings_title: "Einstellungen",
        general:'Allgemeine Informationen',
        your_name: "Ihr Name*",
        postal_code: "PLZ / Postleitzahl",
        state:"Deutscher Staat (Bundesland)*",
        city: "Stadt*",
        full_address: "VollstÃ¤ndige Adresse",
        save_changes: "Ã„nderungen speichern",
        organization:"Ihre Organisation",
        email_address:"E-Mail Adresse*",
        user_name:"Nutzername*",
        biography:"Biografie",
        profile_image:"Profilbild (optional)",
        show_photo:"Aktuelles Foto anzeigen",
        save_changes:"Ã„nderungen speichern",
        password:"Passwort",
        new_password:"Ihr neues Passwort",
        new_password_pl:"Geben Sie Ihr neues Passwort ein",
        confirm_password:"Neues Passwort bestÃ¤tigen",
        confirm_password_pl:"BestÃ¤tigen Sie Ihr neues Passwort",
        password_requirements:"Passwortanforderungen:",
        password_requirements_text:"Stellen Sie sicher, dass diese Anforderungen erfÃ¼llt sind:",
        password_length:"Mindestens 8 Zeichen (und bis zu 100 Zeichen)",
        password_different:"Deutlich anders als Ihre vorherigen PasswÃ¶rter",
        info_updated_successfully:"Ihre Informationen wurden erfolgreich aktualisiert.",
        password_changed_successfully:"Ihr Passwort wurde erfolgreich geÃ¤ndert.",
        success_popup:"âœ… Erfolg!",
        error_popup:"âŒ Fehler!",
        password_same_error:"Das neue Passwort darf nicht mit dem vorherigen Passwort identisch sein.",
        password_short_error:"Das neue Passwort ist zu kurz. Das Passwort muss mindestens 8 Zeichen lang sein.",


        // * MY CHATS PAGE TRANSLATION DICTIONARY

        my_chats_title: "Meine Chats",
        no_messages: "Sie haben keine Nachrichten erhalten.",


        // * MY ADS PAGE TRANSLATION DICTIONARY

        my_ads_title: "Meine Anzeigen",
        ad_title: "Titel",
        ad_image: "Bild",
        state_city: "Bundesland/Stadt",
        rating: "Bewertung",
        status: "Status",
        actions: "Aktionen",
        no_ads:'Sie haben noch keine Anzeige hinzugefÃ¼gt!',


        // * BOOKMARKS PAGE TRANSLATION DICTIONARY

        no_bookmarks: "Sie haben noch keine Lesezeichen gesetzt!",
        Bookmarks: "Lesezeichen",

        // * PLACE AN AD PAGE TRANSLATION DICTIONARY

        title_pl: "Titel*",
        social_id_pl: "soziale ID (optional)",
        full_address_pl: "VollstÃ¤ndige Adresse*",
        volume_pl: "Volumen* ",
        token_name_pl: "Token-Name*",
        telephone_pl: "Telefon (optional)",
        display_email_social_media: "E-Mail und soziale Medien anzeigen",
        ad_added_successfully:"Anzeige wurde erfolgreich hinzugefÃ¼gt.",
        ad_edited_successfully:"Anzeige wurde erfolgreich bearbeitet.",
        ad_description:"Beschreibung*",
        ad_description_place:'Beschreibung eingeben...',
        ad_volume_place:'Token Volumen eingeben',



        // * BASE PAGE TRANSLATION DICTIONARY

        home: "Zuhause",
        privacy_policy: "Datenschutz",
        contact: "Kontakt",
        bookmarks: "Lesezeichen",
        my_ads: "Meine Anzeigen",
        chats: "Chats",
        account: "Konto",
        place_ad: "Anzeige schalten",
        signout: "Abmelden",
        notfications: "Benachrichtigungen",
        new_message_from: "Neue Nachricht von"

    },

    

};



// ! LOCAL STORAGE LANGUAGE HANDLING


let currentLang = localStorage.getItem("lang") || "en";

if (currentLang === "de") {
    translatePage("de");
}

document.getElementById("translate_btn").addEventListener("click", function () {

    // Change the language

    currentLang = currentLang === "en" ? "de" : "en";

    // Save the selected language to localStorage

    localStorage.setItem("lang", currentLang);

    if (currentLang === "de") {
        translatePage("de");
    } else {
        location.reload(); 
    }
});

function translatePage(lang) {
    document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        if (translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Translate placeholders

    document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
        const key = el.getAttribute("data-i18n-placeholder");
        if (translations[lang][key]) {
            el.setAttribute("placeholder", translations[lang][key]);
        }
    });
}

// ! CONSOLE ART

console.log(
`%c
██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗ 
██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗
█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║
██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║
██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝
╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝ 

K R Y P T O   T R E F F
`,
'color:#FF9B00; font-family: monospace; font-size:12px;'
);

// ! DARK MODE

const themeToggleBtn = document.getElementById('theme-toggle');
const darkIcon = document.getElementById('theme-toggle-dark-icon');
const lightIcon = document.getElementById('theme-toggle-light-icon');

const root = document.documentElement;
const classes = ['v2fLMH8w3xgUEQcl63H9', 'dark'];

// وضعیت اولیه
const setInitialTheme = () => {
const isDark =
    localStorage.getItem('color-theme') === 'dark' ||
    (!('color-theme' in localStorage) &&
    window.matchMedia('(prefers-color-scheme: dark)').matches);

root.classList.toggle(classes[0], isDark);
root.classList.toggle(classes[1], isDark);

darkIcon.classList.toggle('hidden', !isDark);
lightIcon.classList.toggle('hidden', isDark);
};

setInitialTheme();

// کلیک روی دکمه
themeToggleBtn.addEventListener('click', () => {
const isDark = root.classList.toggle(classes[0]);
root.classList.toggle(classes[1], isDark);

localStorage.setItem('color-theme', isDark ? 'dark' : 'light');

darkIcon.classList.toggle('hidden', !isDark);
lightIcon.classList.toggle('hidden', isDark);
});