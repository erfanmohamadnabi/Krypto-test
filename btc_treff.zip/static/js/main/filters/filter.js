// ! LIST VIEW JS - Updated to use dynamically injected data with full states/cities

document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. Initialize Dynamic Data from Django Injection ---
    const initialTokenList = window.initialTokenList || [
        { value: 'BTC', label: 'BTC' }, { value: 'ETH', label: 'ETH' }, { value: 'USDT', label: 'USDT' }, { value: 'SHIBA', label: 'SHIBA' }
    ];
    const initialUserState = window.initialUserState || "";
    const initialUserCity = window.initialUserCity || "";

    // --- 2. FULL Static/Template Data for Location (Germany) ---
    const stateCityMap = {
        "Baden-Württemberg": ["Stuttgart", "Mannheim", "Karlsruhe", "Freiburg im Breisgau", "Ulm", "Heidelberg"],
        "Bavaria": ["Munich", "Nuremberg", "Augsburg", "Regensburg", "Würzburg", "Ingolstadt"],
        "Berlin": ["Berlin"],
        "Brandenburg": ["Potsdam", "Cottbus", "Brandenburg an der Havel"],
        "Bremen": ["Bremen", "Bremerhaven"],
        "Hamburg": ["Hamburg"],
        "Hesse": ["Wiesbaden", "Frankfurt am Main", "Kassel", "Darmstadt", "Offenbach am Main"],
        "Lower Saxony": ["Hanover", "Braunschweig", "Osnabrück", "Oldenburg", "Göttingen"],
        "Mecklenburg-Vorpommern": ["Schwerin", "Rostock", "Neubrandenburg", "Stralsund"],
        "North Rhine-Westphalia": ["Düsseldorf", "Cologne", "Dortmund", "Essen", "Bielefeld", "Bonn"],
        "Rhineland-Palatinate": ["Mainz", "Ludwigshafen", "Koblenz", "Trier"],
        "Saarland": ["Saarbrücken"],
        "Saxony": ["Dresden", "Leipzig", "Chemnitz", "Zwickau"],
        "Saxony-Anhalt": ["Magdeburg", "Halle (Saale)", "Dessau-Roßlau"],
        "Schleswig-Holstein": ["Kiel", "Lübeck", "Flensburg", "Neumünster"],
        "Thuringia": ["Erfurt", "Jena", "Weimar", "Gera"],
    };

    const germanyStates = Object.keys(stateCityMap).map(state => ({
        value: state,
        label: state
    }));


    
    // --- 3. Generic Dropdown Setup Function ---
    function setupDropdown(rootId, btnId, dropdownId, searchId, listId, hiddenId){
        const root = document.getElementById(rootId);
        const btn = document.getElementById(btnId);
        const dropdown = document.getElementById(dropdownId);
        const search = document.getElementById(searchId);
        const list = document.getElementById(listId);
        const hidden = document.getElementById(hiddenId);

        let currentItems = [];

        function render(filter=''){
            list.innerHTML='';
            const f = filter.toLowerCase();
            const filtered = currentItems.filter(i=>i.label.toLowerCase().includes(f));
            
            if(!filtered.length){
                const none = document.createElement('div');
                none.textContent='No result';
                none.style.padding='8px';
                list.appendChild(none);
                return;
            }
            filtered.forEach(i=>{
                const row = document.createElement('div');
                row.textContent = i.label;
                row.style.padding = '8px';
                row.style.cursor = 'pointer';
                row.addEventListener('mouseenter', ()=>row.style.background='#f0f0f0');
                row.addEventListener('mouseleave', ()=>row.style.background='transparent');
                row.addEventListener('click', ()=>{
                    btn.textContent = i.label;
                    hidden.value = i.value;
                    dropdown.style.display='none';
                    
                    // Trigger necessary change events here
                    if (rootId === 'stateSelectRoot') {
                        triggerCityUpdate(i.value); // Use i.value (state value)
                    }
                });
                list.appendChild(row);
            });
        }

        btn.addEventListener('click', ()=>{
            if(dropdown.style.display==='block') dropdown.style.display='none';
            else { render(search.value); dropdown.style.display='block'; search.focus(); }
        });
        search.addEventListener('input', e=>render(e.target.value));
        document.addEventListener('mousedown', e=>{ if(!root.contains(e.target)) dropdown.style.display='none'; });

        return {
            setItems: (items)=>{
                currentItems = items;
                hidden.value=''; // reset value
                render(); // Re-render with current search/filter
            },
            setValue: (value, label)=>{
                hidden.value = value;
                btn.textContent = label;
            }
        }
    }

    // --- 4. Initialize Dropdowns ---
    const categoryDropdown = setupDropdown('categorySelectRoot','categoryBtn','categoryDropdown','categorySearch','categoryList','categoryValue');
    const stateDropdown = setupDropdown('stateSelectRoot','stateBtn','stateDropdown','stateSearch','stateList','stateValue');
    const cityDropdown = setupDropdown('citySelectRoot','cityBtn','cityDropdown','citySearch','cityList','cityValue');

    // Set initial items from dynamic data (tokens) and static data (states)
    categoryDropdown.setItems(initialTokenList);
    stateDropdown.setItems(germanyStates);
    cityDropdown.setItems([]); // initially empty city list

    // --- 5. Handle State/City Dependency ---
    function triggerCityUpdate(selectedStateValue) {
        const cityItems = (stateCityMap[selectedStateValue] || []).map(city => ({
            value: city,
            label: city
        }));

        cityDropdown.setItems(cityItems);
        

        if (initialUserState === selectedStateValue && initialUserCity) {
            cityDropdown.setValue(initialUserCity, initialUserCity);
        } else {
            cityDropdown.setValue('', 'Choose city');
        }
    }


    // Event listener on the State List click/selection is handled implicitly by setupDropdown
    // We need to ensure initial values are set correctly AFTER the state dropdown is set up.
    
    // --- 6. Set Initial Values from Django Context ---
    if (initialUserState) {
        stateDropdown.setValue(initialUserState, initialUserState);
        // Important: Load cities based on the initial state immediately
        triggerCityUpdate(initialUserState); 
    }
    
    if (initialUserCity && initialUserState) {
        // If state was set, city will be set inside triggerCityUpdate.
        // If state was NOT set but userCity somehow exists, we set it here as a fallback.
        if (!initialUserState) { 
             cityDropdown.setValue(initialUserCity, initialUserCity);
        }
    } else if (initialUserCity && !initialUserState) {
        // Handle case where only city is known but not state (less likely but for robustness)
         cityDropdown.setValue(initialUserCity, initialUserCity);
    }

    // --- 7. Form Submission Logic (Example) ---
    const filterForm = document.getElementById('your_filter_form_id'); // <--- CHANGE THIS ID
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const token = document.getElementById('categoryValue').value || '';
            const state = document.getElementById('stateValue').value || '';
            const city = document.getElementById('cityValue').value || '';
            
            const url = `?token=${token}&state=${state}&city=${city}`;
            window.location.href = url;
        });
    }
    
    // --- 8. Set Initial Token Filter (if needed for initial load) ---
    const initialTokenValue = document.getElementById('categoryValue').value;
    if (initialTokenValue) {
        const initialToken = initialTokenList.find(t => t.value === initialTokenValue);
        if (initialToken) {
            document.getElementById('categoryBtn').textContent = initialToken.label;
        }
    }

});



// ! SCROLL JS

document.addEventListener('DOMContentLoaded', () => {
    const container = document.querySelector('.grid');
    const sentinel = document.querySelector('#scroll-sentinel');

    const FETCH_LIMIT = 4;  // Number of ads per fetch
    const BUFFER = 40;       // Max ads in DOM
    const VIRTUAL_LIMIT = 200; // Max ads in memory to save RAM

    let lastId = null;
    let loading = false;
    let adsVirtual = [];

    // --- Load ads from backend ---
    async function loadAds() {
        if (loading) return;
        loading = true;

        const params = new URLSearchParams(window.location.search);
        if (lastId) params.set('last_id', lastId);
        params.set('limit', FETCH_LIMIT);

        try {
            const res = await fetch(`?${params.toString()}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();

            if (data.ads.length) {
                // Push to virtual array
                adsVirtual.push(...data.ads);
                lastId = data.last_id;

                // Keep only last VIRTUAL_LIMIT items in memory
                if (adsVirtual.length > VIRTUAL_LIMIT) {
                    adsVirtual.splice(0, adsVirtual.length - VIRTUAL_LIMIT);
                }

                // Render new ads smoothly
                await renderAdsSmooth(data.ads);
            }

            if (!data.has_more) observer.disconnect();
        } catch (err) {
            console.error(err);
        } finally {
            loading = false;
        }
    }

    // --- Smooth rendering: one ad per frame to avoid scroll jump ---
    async function renderAdsSmooth(newAds) {
        for (const ad of newAds) {
            const adHTML = `
                <a href="${ad.absolute_url}" class="ad-item course cursor-pointer flex flex-col bg-white border border-neutral-100 mobile:w-full mobile:m-auto rounded-2xl h-96 dark:bg-dark-card dark:border-none">
                    <div class="h-44 w-full relative">
                        <img loading="lazy" class="h-44 w-full rounded-xl object-cover" src="${ad.image_url}" alt="${ad.title}">
                    </div>
                    <div class="h-28 flex flex-col p-3">
                        <h2 class="text-base font-dana mt-3 font-bold dark:text-white">
                        ${ad.title.length > 64 ? ad.title.slice(0, 64) + '...' : ad.title}
                        </h2>
                        <p class="text-sm opacity-85 font-google mt-2 dark:text-gray-300 line-clamp-2 h-10">
                        ${ad.description.length > 64 ? ad.description.slice(0, 64) + '...' : ad.description}
                        </p>
                    </div>
                    <div class="h-44 flex flex-col p-3 gap-3">
                        <div class="h-8 border-b-[1px] pb-4 border-b-neutral-200/70 flex items-center justify-between">
                            <div class="flex gap-2 h-full items-center justify-center">
                                <svg class="w-6 h-6 ">
                                    <use href="#location"></use>
                                </svg>
                                <p class="font-dana dark:text-gray-300 text-[10px]">${ad.state} - ${ad.city}</p>
                            </div>
                            <div class="flex gap-2 h-full items-center justify-center">
                                <p class="font-dana translate-y-0.5 text-yellow-400">${ad.rate}</p>
                                <svg class="w-6 h-6 text-yellow-400">
                                    <use href="#star"></use>
                                </svg>
                            </div>
                        </div>
                        <div class="h-8 flex items-center justify-between">
                            <div class="flex gap-2 h-full items-center justify-center">
                                <svg class="w-6 h-6">
                                    <use href="#reviews"></use>
                                </svg>
                                <p class="font-dana dark:text-gray-300">${ad.views} <span data-i18n="filter_reviews">Reviews</span></p>
                            </div>
                            <div class="flex gap-2 h-full items-center justify-center">
                                <p class="font-dana translate-y-0.5 dark:text-primary-100">${ad.volume} ${ad.token_name}</p>
                            </div>
                        </div>
                    </div>
            </a>`;

            container.insertAdjacentHTML('beforeend', adHTML);

            const translations = {
                en: { filter_reviews: "Reviews" },
                de: { filter_reviews: "Bewertungen" }
            };

            let currentLang = localStorage.getItem("lang") || "en";

            const reviewsEl = container.querySelectorAll('.ad-item:last-child [data-i18n="filter_reviews"]');
            reviewsEl.forEach(el => {
                if (currentLang === 'de') el.textContent = translations['de']['filter_reviews'];
                else el.textContent = translations['en']['filter_reviews'];
            });


            // Remove oldest if exceeding BUFFER
            const allAds = container.querySelectorAll('.ad-item');
            if (allAds.length > BUFFER) allAds[0].remove();

            // Keep sentinel always last
            container.appendChild(sentinel);

            // Wait for next animation frame to allow scroll to adjust
            await new Promise(requestAnimationFrame);
        }
    }

    // --- Intersection Observer to load more ads ---
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) loadAds();
        });
    }, { root: null, rootMargin: '200px', threshold: 0 });

    if (sentinel) observer.observe(sentinel);

    // --- Initial load ---
    loadAds();

    // --- Check if sentinel visible after resize/scroll to fill page ---
    function maybeLoadMore() {
        if (!sentinel) return;
        const rect = sentinel.getBoundingClientRect();
        if (rect.top < window.innerHeight + 100) loadAds();
    }
    window.addEventListener('resize', maybeLoadMore);
    window.addEventListener('scroll', maybeLoadMore);
});

