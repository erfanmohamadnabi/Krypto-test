


// ! BASE SCRIPTS


// * MENU SCRIPTS

$(document).ready(function(){

    //* MENU OPEN & CLOSE

    $(".open-icon").click(function(){
        $(".mask").fadeIn()
        $(".humberger-menu").removeClass("close-menu")
        $(".humberger-menu").addClass("open-menu")

    })

    $(".close-icon").click(function(){
        $(".humberger-menu").removeClass("open-menu")
        $(".humberger-menu").addClass("close-menu")
        $(".mask").fadeOut()

    })

    //* MENU OPEN & CLOSE

    //* SUB MENU OPEN & CLOSE

    $(".mobile-menu").click(function(){
    $(".sub-menu").not($(this).children(".sub-menu")).removeClass("active");
    $(".mobile-menu").not(this).find(".sub-svg").removeClass("rotate");

    $(this).children(".sub-menu").toggleClass("active");
    $(this).find(".sub-svg").toggleClass("rotate");

    //* SUB MENU OPEN & CLOSE
});

})

// * CONSOLE ART

console.log(
`%c
██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗ 
██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗
█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║
██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║
██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝
╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝ 

K R Y P T O   T R E F F
`,
'color:#FF9B00; font-family: monospace; font-size:12px;'
);



// ! HEADER FIXED

const header = document.getElementById('header');
const initialClasses = "h-24 bg-white flex items-center justify-between shadow-sm"; 

const fixedClasses = "fixed top-0 left-0 right-0 w-full shadow-lg z-10"; 
const threshold = 1; 

function handleScroll() {
    if (window.scrollY > threshold) {

        header.classList.add(...fixedClasses.split(' '));

        header.classList.remove('shadow-sm');
    } else {

        header.classList.remove(...fixedClasses.split(' '));

        header.classList.add('shadow-sm'); 
    }
}


header.className = initialClasses;

window.addEventListener('scroll', handleScroll);

handleScroll();


// ! TRANSLATE MAIN PAGES

const translations = {

    // * PROFILE PAGE TRANSLATION DICTIONARY

    de: {
        
        // * BASE 

        // HEADER

        states: 'Regionen',
        category: 'Kategorien',
        place_ad: 'Anzeige',
        about: 'Über uns',
        contact: 'Kontakt',
        search_place:'wonach suchst du?',
        privacy:'datenschutzrichtlinie',

        // FOOTER

        abtitle:'Wer wir sind',
        adtext:'Krypto Treff ist Ihre erste Adresse für sicheren, persönlichen Kryptowährungshandel. Wir verbinden digitale Assets mit echtem Vertrauen – schnell, geprüft und transparent. Ihre Sicherheit steht bei uns an erster Stelle.',
        actitle:'Aktion & Benutzer',
        my_account:'Mein Konto',
        my_chats:'Meine Chats',
        quick:'Schneller Zugriff',
        fotext:'Alle materiellen und geistigen Eigentumsrechte sind Krypto treff vorbehalten.',
        
        // CONTACT

        cntitle:'Kontaktieren Sie uns',
        cnname:'Vollständiger Name *',
        cnop1:'Bitte auswählen',
        cnop2:'Allgemeine Anfrage',
        cnop3:'Unterstützung',
        cnop4:'Rückmeldung',
        cnop5:'Partnerschaft',
        cnop6:'Andere',
        cntitlei:'Titel *',
        cnmessage:'Nachricht*',

        // HELP

        rltitle:'Häufig gestellte Fragen',
        hl1title:'Wie kann ich die Sicherheit meiner Kryptowährung bei einer persönlichen Transaktion gewährleisten?',
        rl1text:'Sicherheit hat für uns höchste Priorität. Wir empfehlen dringend, sich nur an vorab genehmigten, öffentlichen Orten (wie belebten Bankfilialen oder überwachten Einkaufszentren) und tagsüber zu treffen. Führen Sie die Überweisungsbestätigung immer auf Ihrem eigenen Gerät durch, bevor Sie den Austausch abschließen.',
        rl2title:'Wie läuft die Überprüfung einer Kryptowährungsüberweisung ab?',
        rl2text:'Der Ablauf ist einfach: Zuerst einigen Sie sich auf den genauen Betrag. Sobald Sie sich am Treffpunkt befinden, veranlasst der Verkäufer die Überweisung. Sie müssen warten, bis die Transaktion in der Blockchain vollständig bestätigt und in Ihrer Wallet sichtbar ist, bevor Sie Fiatgeld überweisen.',
        rl3title:'Wie werden die Wechselkurse für persönliche Transaktionen festgelegt?',
        rl3text:'Der zum Zeitpunkt der Vereinbarung auf unserer Plattform angezeigte Kurs ist der Referenzkurs. Etwaige endgültige Anpassungen oder Servicegebühren müssen von beiden Parteien vor Beginn des physischen Austauschs ausdrücklich bestätigt werden.',
        rl4title:'Welche Vorsichtsmaßnahmen sollte ich treffen, wenn ich mit einem hohen Geldbetrag handle?',
        rl4text:'Bei Transaktionen mit hohem Wert empfehlen wir, einen vertrauenswürdigen Zeugen hinzuzuziehen oder einen Ort mit hohen Sicherheitsvorkehrungen zu nutzen. Führen Sie nicht unnötig große Bargeldsummen mit sich; idealerweise sollten beide Parteien auf eine schnelle und diskrete Transaktion vorbereitet sein.',

        pltitle:'Website-Regeln',

        plquestion:'Welche Website-Regeln gelten?',

        pl1title:'1. Annahme der Bedingungen',
        pl1text:'Die Fähigkeit, diese Bedingungen einzugehen und allen anwendbaren lokalen, staatlichen, bundesstaatlichen und internationalen Gesetzen und Vorschriften zuzustimmen.',
        pl2title:'2. Art der Dienstleistung',
        pl2text:'Unsere Plattform dient als Marktplatz, auf dem Nutzer miteinander in Kontakt treten und Peer-to-Peer-Kryptowährungstransaktionen abwickeln können. Wir fungieren bei diesen Transaktionen weder als Vermittler noch als Treuhänder.',
        pl3title:'3. Verantwortlichkeiten des Nutzers',
        pl3text:'Die Nutzer tragen die alleinige Verantwortung für ihr Handeln auf der Plattform, einschließlich der Einhaltung aller relevanten Gesetze und Vorschriften, die Kryptowährungstransaktionen in ihrer jeweiligen Gerichtsbarkeit regeln.',
        pl4title:'4. Verbotene Aktivitäten',
        pl4text:'Nutzer dürfen keine illegalen Aktivitäten, Betrug, Geldwäsche oder Handlungen durchführen, die die Integrität der Plattform oder ihrer Nutzer beeinträchtigen könnten.',
        pl5title:'5. Sicherheitsmaßnahmen',
        pl5text:'Nutzer werden angehalten, alle notwendigen Vorsichtsmaßnahmen zu treffen, um ihre Sicherheit bei persönlichen Transaktionen zu gewährleisten, einschließlich Treffen an öffentlichen Orten und Überprüfung von Transaktionen auf ihren eigenen Geräten.',
        pl6title:'6. Streitbeilegung',
        pl6text:'Wir vermitteln keine Streitigkeiten zwischen Nutzern. Alle Probleme, die aus Transaktionen entstehen, müssen direkt zwischen den beteiligten Parteien gelöst werden.',
        pl7title:'7. Haftungsbeschränkung',
        pl7text:'Wir haften nicht für Verluste oder Schäden, die aus Transaktionen über die Plattform resultieren.',
        pl8title:'8. Änderungen der Bedingungen',
        pl8text:'Wir behalten uns das Recht vor, diese Bedingungen jederzeit zu ändern. Die fortgesetzte Nutzung der Plattform gilt als Zustimmung zu den Änderungen.',
        pl9title:'9. Kontaktinformationen',
        pl9text:'Bei Fragen oder Bedenken zu diesen Bedingungen wenden Sie sich bitte an unser Support-Team.',


        // INDEX

        intitle:'Kauf & Verkauf digitaler Währungen ',
        intext:'Auf der großen und renommierten Krypto-Treff-Plattform können Sie hier Währungen sicher kaufen und verkaufen.',
        inplace:'Anzeige aufgeben',
        explore:'Anzeigen entdecken',
        prtitle:'Sofortige Kryptowährungspreise',
        prtext:'Preise für Kryptowährungen',
        coinprice:'Aktueller Preis',
        coinchange:'Änderung (24 Std.)',
        cointransition:'Transaktion',
        coinbtn:'kaufen und verkaufen',
        coinsee:'mehr sehen',
        in_adstitle:'Neue Anzeigen entdecken',
        in_adstext:'Tausende Anzeigen durchsuchen',
        ad_alllink:'Alle Anzeigen ansehen',
        questions_title:'Womit können wir Ihnen helfen?',
        questions_text :'Kaufen und verkaufen Sie sicher auf dieser Plattform',
        qu1title:'Vollständige Zahlung persönlich',
        qu1text:'Ihre Transaktionen werden vollständig persönlich durchgeführt, es wird kein Geld über die Website bezahlt.',
        q2title:'Permanente Unterstützung',
        qu2text:'Unser Team hilft Ihnen jederzeit bei Fragen oder Problemen – für eine sorgenfreie Transaktion.',
        qu3title:'Hohe Sicherheit',
        qu3text:'Handeln Sie mit Vertrauen. Alle Nachrichten und Transaktionen sind geschützt.',
        qu4title:'Einfaches Kaufen und Verkaufen',
        qu4text:'Die schnellste und sicherste Plattform zum Kauf und Verkauf von Währungen in Ihrem Zuhause.',

        vis1title:'Alles auf einen Blick',
        vis1text:'Erstellen Sie Ihre Anzeige und so können Sie schnell auf der Karte gefunden werden.',
        vis2title:'Schnell und sicher',
        vis2text:'Kaufen und verkaufen Sie sicher mit geprüften Nutzern in Ihrer Nähe.',
        vis3title:'Sofortige Transaktionen',
        vis3text:'Sobald Sie sich mit einem Käufer oder Verkäufer treffen, können Sie sofort handeln.',


        roadtitle:'Beliebte Währungen',
        roadtext:'Beliebte und meistverkaufte Währungen auf der Website',

        // LIST

        filter_category:'Wählen Sie eine Kategorie',
        filter_state:'Wählen Sie ein Bundesland',
        filter_city:'Wählen Sie eine Stadt',
        filter_btn:'Aktualisieren',
        filter_reviews:'Rezensionen',

        // DETAIL

        safety:'Sicherheitsleitfaden und Regeln',
        send_email:'EMail senden',
        chat_btn:'Chatten',
        ad_volume:'Volumen',
        ad_unknown:'unbekannt',
        ad_social:'Soziale Netzwerke',
        ad_telephone:'Telefon',
        ad_address:'Vollständige Adresse',
        ad_description:'Beschreibung',
        ad_report:'Anzeige melden',
        ad_write_comment:'Einen Kommentar schreiben',
        ad_omments_cm:'Kommentare *',
        ad_comment_place_message:'Geben Sie Ihren Kommentar ein ...',
        ad_comment_place_name:'Geben Sie Ihren Namen ein ...',
        ad_comment_submit:'Absenden',
        ad_comments:'Kommentare',
        
        // * POPUPS

        search_btn:'Suchen',
        popsearch:'Erfolg!',
        popscmessage:'Ihre Aktion wurde erfolgreich abgeschlossen.'

    },

    

};



// ! LOCAL STORAGE LANGUAGE HANDLING


function updateFlag(lang) {
    document.querySelectorAll(".translate_btn").forEach(btn => {
        const de = btn.querySelector(".germany-flag");
        const en = btn.querySelector(".america-flag");

        if (!de || !en) return;

        if (lang === "en") {
            de.classList.add("hidden");
            en.classList.remove("hidden");
        } else {
            en.classList.add("hidden");
            de.classList.remove("hidden");
        }
    });
}



let currentLang = localStorage.getItem("lang") || "en";
updateFlag(currentLang);




if (currentLang === "de") {
    translatePage("de");
}

document.querySelectorAll(".translate_btn").forEach(btn => {
    btn.addEventListener("click", function () {
        const de = btn.querySelector(".germany-flag");
        const en = btn.querySelector(".america-flag");

        currentLang = currentLang === "en" ? "de" : "en";
        localStorage.setItem("lang", currentLang);

        if (currentLang === "de") {
            translatePage("de");
            de.classList.remove("hidden");
            en.classList.add("hidden");
        } else {
            de.classList.add("hidden");
            en.classList.remove("hidden");
            location.reload();
        }

    });
});


function translatePage(lang) {
    document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        if (translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Translate placeholders

    document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
        const key = el.getAttribute("data-i18n-placeholder");
        if (translations[lang][key]) {
            el.setAttribute("placeholder", translations[lang][key]);
        }
    });
}