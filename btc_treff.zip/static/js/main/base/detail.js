// ! SAVE AD

document.addEventListener("DOMContentLoaded", function () {
  const saveIcon = document.getElementById("save-btn");
  const iconSaveSymbol = document.getElementById("icon-save");
  if (!saveIcon || !iconSaveSymbol) return;

  const saveStatus = window.initialSaveStatus;

  if (saveStatus === "none") {
    iconSaveSymbol.setAttribute("fill", "none");
    saveIcon.dataset.saved = "false";
  } else {
    iconSaveSymbol.setAttribute("fill", "currentColor");
    saveIcon.dataset.saved = "true";
  }

  saveIcon.addEventListener("click", function () {
    const isSaved = saveIcon.dataset.saved === "true";

    iconSaveSymbol.setAttribute("fill", isSaved ? "none" : "currentColor");
    saveIcon.dataset.saved = (!isSaved).toString();
  });
});

function Save_to() {
  fetch(`/v/${window.initialAdId}/${window.initialAdSlug}?save=save`)
    .then((r) => r.json())
    .then((data) => {
      const res = document.getElementById("result");
      if (res) res.textContent = data.result;
    })
    .catch((err) => console.error("Fetch error:", err));
}

// ! SHARE AD

document.addEventListener("DOMContentLoaded", function () {
  const shareBtn = document.getElementById("share-btn");
  if (!shareBtn) return;

  shareBtn.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      alert("The page link was copied ✅");
    } catch {
      alert("I couldn’t copy the link 😕");
    }
  });
});

// ! MAP

document.addEventListener("DOMContentLoaded", function () {

  window.addEventListener("load", () => {
    const leafletCSS = document.createElement("link");
    leafletCSS.rel = "stylesheet";
    leafletCSS.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(leafletCSS);

    const leafletJS = document.createElement("script");
    leafletJS.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    leafletJS.onload = () => {
      const y = parseFloat(window.mapY);
      const x = parseFloat(window.mapX);
      const center = y && x ? [y, x] : [window.mapFallbackY, window.mapFallbackX];

      const map = L.map("map").setView(center, 12);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap contributors",
      }).addTo(map);

      L.marker(center).addTo(map).bindPopup(window.adTitle).openPopup();
    };
    document.body.appendChild(leafletJS);
  });
});


// ! RATE AD

document.addEventListener("DOMContentLoaded", () => {
  const stars = document.querySelectorAll(".star-icon");
  if (!stars.length) return;

  const ICON_FILL = "#icon-star-fill";
  const ICON_EMPTY = "#icon-star-solid";

  function update(rating) {
    stars.forEach((star) => {
      const use = star.querySelector("use");
      use.setAttribute(
        "href",
        parseInt(star.dataset.starIndex) <= rating ? ICON_FILL : ICON_EMPTY,
      );
    });
  }

  stars.forEach((star) => {
    star.addEventListener("click", (e) => {
      const rate = parseInt(e.currentTarget.dataset.starIndex);
      update(rate);

      fetch(`/v/${window.initialAdId}/${window.initialAdSlug}?rate=${rate}`)
        .then((r) => r.json())
        .then((d) => {
          

          if (d.status__rate === "You must be logged in to rate!") {
            const open = document.querySelector(
              'button[command="show-modal"][commandfor="dialog"]'
            );
            if (open) open.click();
          }else{
            alert(d.status__rate);
          }
        });

    });
  });

  update(0);
});

// ! MESSAGE TO SELLER

function Message_to() {
  fetch(`/v/${window.initialAdId}/${window.initialAdSlug}?message=message`)
    .then((response) => {
      // کاربر لاگین نیست
      if (response.status === 401) {
        return response.json().then((data) => {
          alert("Please login first");
          window.location.href = data.redirect_url || "/accounts/signin";
        });
      }

      // پیام به خود
      if (response.status === 400) {
        return response.json().then((data) => {
          alert(data.message);
        });
      }

      return response.json();
    })
    .then((data) => {
      if (!data) return;

      if (data.status === "success" && data.redirect_url) {
        window.location.href = data.redirect_url;
      }
    })
    .catch((err) => {
      console.error("Fetch error:", err);
      alert("Something went wrong 😕");
    });
}

// ! VIEW MORE COMMENTS

document.addEventListener("DOMContentLoaded", () => {
  const moreCommentsContainer = document.getElementById(
    "more-comments-container",
  );
  const viewMoreButton = document.getElementById("view-more-button");

  if (!moreCommentsContainer || !viewMoreButton) return;

  viewMoreButton.addEventListener("click", () => {
    moreCommentsContainer.classList.remove("hidden");
    viewMoreButton.remove(); // دکمه کامل حذف میشه
  });
});

// ! REPORT SCRIPT

document.addEventListener("DOMContentLoaded", () => {
  const forms = document.getElementsByClassName("ad-report-form");
  for (let i = 0; i < forms.length; i++) {
    forms[i].addEventListener("submit", function (event) {
      event.preventDefault();
      const form = event.target;
      const url = form.getAttribute("action");
      const method = form.getAttribute("method");
      const formData = new FormData(form);
      fetch(url, { method: method, body: formData })
        .then((response) => response.json())
        .then((data) => {
          if (data.status__report) {
            alert(data.status__report);
            form.reset();
            document
              .querySelector(
                'button[command="close"][commandfor="dialog-report"]',
              )
              .click();
          }
        })
        .catch((error) => console.error("خطا:", error));
    });
  }
});
