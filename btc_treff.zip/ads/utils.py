from PIL import Image
from io import BytesIO
from django.core.files.base import ContentFile
import os

def compress_image(image):
    img = Image.open(image)

    if img.mode in ("RGBA", "P"):
        img = img.convert("RGB")

    img.thumbnail((300, 300))

    buffer = BytesIO()
    img.save(
        buffer,
        format="WEBP",
        quality=55,
        method=6   
    )

    file_name = os.path.splitext(image.name)[0] + ".webp"
    return ContentFile(buffer.getvalue(), name=file_name)
