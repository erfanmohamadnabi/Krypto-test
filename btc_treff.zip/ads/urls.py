from django.urls import path
from .views import (
    AddAdvertisementView,
    AdvertisementListView,
    AdvertisementDelete,
    AdvertisementDetailView,
    Rules,
    Bookmarks,
    DeleteBookmark
)


urlpatterns = [
    
    # Add & edit ads

    path('accounts/my-ads/', AdvertisementListView, name='advertisements'),
    path('accounts/bookmarks/', Bookmarks, name='bookmarks'),
    path('accounts/addadvertisement/', AddAdvertisementView, name='addadvertisement'),
    path('accounts/addadvertisement/<int:id>/', AddAdvertisementView, name='editadvertisement'),
    path('accounts/my-ads/delete/<str:ix>/', AdvertisementDelete, name='advertisementdelete'),
    path('accounts/bookmarks/delete/<str:ix>/', DeleteBookmark, name='bookmarkdelete'),
    # Ad detail page

    path('v/<str:ix>/<slug:slug>/', AdvertisementDetailView, name='advertisementdetail'),

    # Ad rules page

    path('help', Rules, name='help'),
]

