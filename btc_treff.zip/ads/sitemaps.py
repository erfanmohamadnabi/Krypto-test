# ads/sitemaps.py
from django.contrib.sitemaps import Sitemap
from .models import Ads
from django.urls import reverse

class StaticViewSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.8

    def items(self):
        return ['home', 'contact']  
    def location(self, item):
        return reverse(item)


class AdsSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.9

    def items(self):
        return Ads.objects.all()  

    def lastmod(self, obj):
        return obj.date  
