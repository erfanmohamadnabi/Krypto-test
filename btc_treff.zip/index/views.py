from django.core.cache import cache
import requests
from django.shortcuts import render
from ads.models import Ads

# ! INDEX VIEW

def Index(request):

    # ! ADS EXPLEORE

    ads = Ads.objects.all().order_by('-id')[:8]

    # ! CRYPTO PRICES

    cryptos = cache.get('crypto_prices')

    if not cryptos:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            "ids": "bitcoin,tether,ethereum,tron,shiba-inu",
            "vs_currencies": "usd",
            "include_24hr_change": "true"
        }
        response = requests.get(url, params=params, timeout=3)
        data = response.json()

        cryptos = [
            {
                "name": "BTC Bitcoin",
                "symbol": "BTC",
                "price": data["bitcoin"]["usd"],
                "change": round(data["bitcoin"]["usd_24h_change"], 2),
                "icon": "btc.svg",
            },
            {
                "name": "USDT Tether",
                "symbol": "USDT",
                "price": data["tether"]["usd"],
                "change": round(data["tether"]["usd_24h_change"], 2),
                "icon": "usdt.svg",
            },
            {
                "name": "Ethereum",
                "symbol": "ETH",
                "price": data["ethereum"]["usd"],
                "change": round(data["ethereum"]["usd_24h_change"], 2),
                "icon": "eth.svg",
            },
            {
                "name": "Tron",
                "symbol": "TRX",
                "price": data["tron"]["usd"],
                "change": round(data["tron"]["usd_24h_change"], 2),
                "icon": "trx.svg",
            },
            {
                "name": "Shiba Inu",
                "symbol": "SHIB",
                "price": data["shiba-inu"]["usd"],
                "change": round(data["shiba-inu"]["usd_24h_change"], 2),
                "icon": "shiba.svg",
            },
        ]

        cache.set('crypto_prices', cryptos, 1600) 

     

    return render(request, 'main/index.html', {"cryptos": cryptos, "ads": ads})
