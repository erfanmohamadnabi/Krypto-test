from chat.models import Chat,Message
from django.db.models import Count, Q
from user_account.models import Notification

def Site_Data(request):

    # User Notifications
    notfications = []
    if request.user.is_authenticated:
        notfications = Notification.objects.all().order_by('-created_at')[:5]
        

    # User Chats
    if not request.user.is_authenticated:
        return {}
    else:
        chats = Chat.objects.filter(Q(user_one=request.user) | Q(user_two=request.user))
        has_unread = False
        # Messages count for each chat
        
        result = []
        for chat in chats:
            unread_count = Message.objects.filter(chat=chat, seen=False).exclude(user=request.user).count()
            # print(unread_count)
            second_user = chat.user_two if chat.user_one == request.user else chat.user_one

            if unread_count > 0 and unread_count != None:
                has_unread = True
            

            result.append({
                'chat': chat,
                'unread_count': unread_count,
                'user': second_user
            })

    return {'messages': result,'has_unread':has_unread,'notfications':notfications}