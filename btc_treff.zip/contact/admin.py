from django.contrib import admin
from .models import ContactMessage

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):

    list_display = ('name', 'email', 'title', 'subject', 'short_message', 'created_at')
    
    list_display_links = ('name', 'email', 'title')
    
    list_filter = ('created_at', 'subject')
    
    search_fields = ('name', 'email', 'title', 'subject', 'message')
    
    readonly_fields = ('created_at',)
    
    list_per_page = 20

    ordering = ('-created_at',)

    def short_message(self, obj):
        return obj.message[:50] + "..." if len(obj.message) > 50 else obj.message
    short_message.short_description = 'Message Preview'
