from django.urls import path
from .views import (
    ContactPage
)


urlpatterns = [
    
    # Contact page

    path('contact', ContactPage, name='contact'),
]

