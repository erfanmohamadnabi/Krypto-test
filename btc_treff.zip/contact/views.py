from django.shortcuts import render
from .models import ContactMessage
# Create your views here.


def ContactPage(request):
    context = {}

    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        title = request.POST.get("title")
        subject = request.POST.get("subject")
        message = request.POST.get("message")

        contact_message = ContactMessage(
            name=name,
            email=email,
            title=title,
            subject=subject,
            message=message
        )
        contact_message.save()

        context['success'] = True

        print("Message received:", name, email, title, subject, message)

        # Here you can handle the form data, e.g., save it to the database or send an email

    return render(request, 'main/contact.html', context)