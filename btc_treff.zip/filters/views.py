from django.shortcuts import render
from django.http import JsonResponse
from ads.models import Ads, Token
from django.views.decorators.http import require_GET
import json
from django.db.models import Q

@require_GET
def ListView(request):
    """
    Optimized ListView for large-scale ads with cursor pagination.
    """
    LIMIT = int(request.GET.get("limit", 20))
    token_filter = request.GET.get("token")
    state_filter = request.GET.get("state")
    city_filter = request.GET.get("city")
    serch_filter =  request.GET.get('search_ad')

    


    last_id = request.GET.get("last_id")  # cursor

    is_ajax = (
        request.headers.get("x-requested-with") == "XMLHttpRequest"
        or request.GET.get("ajax") == "1"
    )

    # Token list for frontend dropdown (only if not AJAX)
    token_list_json_string = "[]"
    if not is_ajax:
        tokens = Token.objects.all()
        token_list_json_string = json.dumps(
            [{"value": t.token, "label": t.token} for t in tokens]
        )

    # Base queryset
    ads_queryset = Ads.objects.select_related("token_name").only(
        "id","title","description","image","views","rate","volume","state","city","token_name__token"
    ).order_by("-id")

    # Apply filters
    if token_filter:
        ads_queryset = ads_queryset.filter(token_name__token__iexact=token_filter)
    if state_filter:
        ads_queryset = ads_queryset.filter(state__iexact=state_filter)
    if city_filter:
        ads_queryset = ads_queryset.filter(city__iexact=city_filter)

    if serch_filter:
        ads_queryset = ads_queryset.filter(
            Q(title__icontains=serch_filter) |
            Q(description__icontains=serch_filter)
        )

    # Cursor pagination
    if last_id:
        ads_queryset = ads_queryset.filter(id__lt=last_id)

    final_ads = list(ads_queryset[:LIMIT])

    if not is_ajax:
        return render(request, "main/filters/list.html", {
            "ads": final_ads,
            "token_list_json": token_list_json_string,
            "request": request
        })

    # Prepare JSON
    ads_data = [
        {
            "id": ad.id,
            "title": ad.title,
            "description": ad.description[:65],
            "image_url": ad.image.url if ad.image else "/static/default-image.jpg",
            "views": ad.views,
            "rate": ad.rate,
            "volume": ad.volume,
            "token_name": ad.token_name.token if ad.token_name else "",
            "state": ad.state,
            "city": ad.city,
            "absolute_url": ad.get_absolute_url(),
        }
        for ad in final_ads
    ]

    has_more = len(ads_data) == LIMIT
    last_id_cursor = ads_data[-1]["id"] if ads_data else None

    return JsonResponse({
        "ads": ads_data,
        "has_more": has_more,
        "last_id": last_id_cursor
    })
