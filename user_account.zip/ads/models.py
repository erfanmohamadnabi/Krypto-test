from django.db import models
from user_account.models import CustomUser
from datetime import datetime
from django.utils import timezone
from datetime import datetime
from django.urls import reverse

# # Create your models here.

date_now = datetime.now().date()

# ! TOKENS MODEL

class Token(models.Model):
    token = models.CharField(verbose_name='token name',max_length=1000)

    def __str__(self):
        return self.token
    
# ! ADS MODEL

class Ads(models.Model):
    user = models.ForeignKey(CustomUser,verbose_name='user',on_delete=models.CASCADE)
    token_name = models.ForeignKey(Token,verbose_name='token name',on_delete=models.CASCADE)
    volume = models.IntegerField(default=0,verbose_name='volume')
    title = models.CharField(verbose_name='title',max_length=1000)
    rate = models.FloatField(default=0,verbose_name='rate')
    views = models.IntegerField(verbose_name='reviews',default=0)
    description = models.TextField(verbose_name='description')
    image = models.ImageField(verbose_name='image',upload_to='ads_images/',default='ads_images/default.jfif')
    full_address = models.CharField(verbose_name='full address',max_length=1000)
    telephone = models.CharField(verbose_name='telephone',max_length=100,blank=True,null=True)
    ad_map = models.CharField(verbose_name='ad map',max_length=1000,blank=True,null=True)
    state = models.CharField(verbose_name='state',max_length=100)
    city = models.CharField(verbose_name='city',max_length=100)
    socal_id = models.CharField(verbose_name='social id',max_length=1000,blank=True,null=True)
    date = models.CharField(default=date_now,verbose_name='date')
    email_show = models.BooleanField(default=False,verbose_name='email show')

    # * SEO FIELDS 

    slug = models.CharField(verbose_name='slug',max_length=1000,null=True,blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = self.title.replace(" ", "-")
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name="users ad"
        verbose_name_plural="ads"

    # def get_absolute_url(self):
    #     return reverse("dvertisementdetail", args=[self.ix, self.slug])


# ! SAVED ADS MODEL

class SavedAds(models.Model):
    ad = models.ForeignKey(Ads,verbose_name='ad',on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser,verbose_name='user',on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.username} - {self.ad.title}"

    class Meta:
        verbose_name="saved ad"
        verbose_name_plural="saved ads"


# ! RATE ADS MODEL
    
class RateAds(models.Model):
    ad = models.ForeignKey(Ads,verbose_name='ad',on_delete=models.CASCADE)
    rate = models.IntegerField(verbose_name='rate',default=0)
    user = models.ForeignKey(CustomUser,verbose_name='user',on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.ad.title} - {self.rate}"
    
    class Meta:
        verbose_name="ad rate"
        verbose_name_plural="ads rates"


# ! COMMENTS ADS MODEL

class ComeentsAds(models.Model):
    ad = models.ForeignKey(Ads,verbose_name='ad',on_delete=models.CASCADE)
    comment = models.TextField(verbose_name='comment')
    name = models.CharField(verbose_name='name',max_length=200)
    user = models.ForeignKey(CustomUser,verbose_name='user',on_delete=models.CASCADE)
    date = models.CharField(default=date_now,verbose_name='date')

    def __str__(self):
        return self.comment
    
    class Meta:
        verbose_name="ad comment"
        verbose_name_plural="ads comments"


# ! REPORT ADS MODEL

types = {
    "spam" : "spam",
    "inappropriate" : "inappropriate",
    "fraud" : "fraud",
    "other" : "other"
}

class ReportAds(models.Model):
    ad = models.ForeignKey(Ads,verbose_name='ad',on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser,verbose_name='user',on_delete=models.CASCADE)
    report_type = models.CharField(verbose_name='report type',max_length=100,choices=types)
    description = models.TextField(verbose_name='description')

    def __str__(self):
        return self.description
    
    class Meta:
        verbose_name = "ad report"
        verbose_name_plural = "ads reports"
