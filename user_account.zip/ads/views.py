from django.shortcuts import render, redirect, get_object_or_404
from .models import *
import requests
from user_account.models import CustomUser
from datetime import datetime, date
from django.utils import timezone
from django.http import JsonResponse
from django.db.models import Sum,Avg
from chat.models import Chat,Message
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from .utils import compress_image

# Create your views here.

# !!!!!!!!!!!!!!!!!! PROFILE VIEWS !!!!!!!!!!!!!!!!!!!!!

# ! ADD ADS

@login_required(login_url='/accounts/signin')
def AddAdvertisementView(request,id=None):
    tokens =  Token.objects.all()
    context = {"tokens":tokens}

    # Edit existing ad

    if id is not None:
        ad = get_object_or_404(Ads, id=id)
        if ad.ad_map:
            parts = [p.strip() for p in ad.ad_map.split(',') if p.strip()]
            if len(parts) >= 2:
                context["map_y"] = parts[0]
                context["map_x"] = parts[1]
        context["ad"] = ad

        if request.method == "POST" or request.FILES :
            ad.title = request.POST.get("title")
            ad.socal_id = request.POST.get("social")
            ad.description = request.POST.get("description")
            # update image only if a new file was uploaded
            if request.FILES.get("image"):
                ad.image = request.FILES.get("image")
            ad.state = request.POST.get("state")
            ad.city = request.POST.get("city")
            ad.full_address = request.POST.get("address")
            ad.telephone = request.POST.get("phone")
            ad.email_show = request.POST.get("display_email") == "on"
            token_id = request.POST.get("token_id")
            if token_id:
                ad.token_name = Token.objects.get(id=token_id)
            ad.volume = request.POST.get("volume")
            ad.ad_map = request.POST.get("coordinates") or ad.ad_map
            ad.save()
            context["success_edit"] = True
            
            return render(request, 'profile/add_place.html', context)

    # Create new ad

    else:
        if request.method == "POST":
            token = Token.objects.get(id=request.POST.get("token_id")) if request.POST.get("token_id") else None

            new_add = Ads.objects.create(
                user=request.user,
                token_name=token,
                volume=request.POST.get("volume"),
                title=request.POST.get("title"),
                description=request.POST.get("description"),
                telephone=request.POST.get("phone"),
                full_address=request.POST.get("address"),
                state=request.POST.get("state"),
                city=request.POST.get("city"),
                socal_id=request.POST.get("social"),
                email_show=(request.POST.get("display_email") == "on"),
                ad_map=request.POST.get("coordinates"),
            )
            

            # * CHECK IMAGE FILED

            if  request.FILES.get("image"):
                c_image = compress_image(
                    request.FILES.get("image")
                )
                new_add.image = c_image

            new_add.save()

            context["success_add"] = True
    

    return render(request, 'profile/add_place.html', context)


# ! AD LIST

@login_required(login_url='/accounts/signin')
def AdvertisementListView(request):
    ads = Ads.objects.all().order_by('-id')

    context = {"ads":ads}
    return render(request, 'profile/ads.html',context)


# ! DELETE ADS

@login_required(login_url='/accounts/signin')
def AdvertisementDelete(request,ix):
    ad_index = Ads.objects.get(id = ix)
    if ad_index.user == request.user:
        ad_index.delete()
    else:
        pass
    return redirect("/accounts/my-ads")



# !!!!!!!!!!!!!!!!!! MAIN PAGES !!!!!!!!!!!!!!!!!!!!!!!


# ! DETAIL VIEW

def AdvertisementDetailView(request,ix,slug):
    ad = get_object_or_404(Ads, id=ix, slug=slug)
    comments = ComeentsAds.objects.filter(ad=ad).order_by('-id')

    save__index = None
    rate_index = None
    if request.user.is_authenticated:
        save__index = SavedAds.objects.filter(ad=ad, user=request.user).first()
        rate_index = RateAds.objects.filter(ad=ad, user=request.user).first()

    # increment view count
    ad.views = (ad.views or 0) + 1
    ad.save()

    # map coordinates (guarded)
    mapy = mapx = None
    if ad.ad_map:
        parts = [p.strip() for p in ad.ad_map.split(',') if p.strip()]
        if len(parts) >= 2:
            mapy, mapx = parts[0], parts[1]

    # save/unsave ad
    if request.GET.get("save") is not None:
        if request.user.is_authenticated:
            if save__index is None:
                SavedAds.objects.create(ad=ad, user=CustomUser.objects.get(id=request.user.id))
            else:
                save__index.delete()

    # rate ad
    if request.GET.get("rate") is not None:
        rate_value = request.GET.get("rate")
        if not request.user.is_authenticated:
            return JsonResponse({'status__rate': "You must be logged in to rate!"})

        if rate_index is None:
            RateAds.objects.create(rate=rate_value, user=request.user, ad=ad)
            # update avg for this ad only
            avg_ad_rate = RateAds.objects.filter(ad=ad).aggregate(total_avg=Avg('rate'))
            avg_rate = avg_ad_rate.get('total_avg') or 0
            try:
                ad.rate = int(avg_rate)
            except Exception:
                ad.rate = 0
            ad.save()
            return JsonResponse({'status__rate': "Your score has been recorded"})
        return JsonResponse({'status__rate': "Your score has already been registered!"})

    # comment (POST)
    if request.method == "POST" and request.POST.get("comment"):
        ComeentsAds.objects.create(
            ad=ad,
            name=request.POST.get("commnet__name"),
            user=request.user,
            comment=request.POST.get("comment"),
        )
        print("comment saved")

    # new message
    if request.GET.get("message"):
        if not request.user.is_authenticated:
            print("passs")
            return JsonResponse({"status": "error", "redirect_url": "/accounts/login/"}, status=401)
        else:
            if ad.user == request.user:
                print("can't message yourself")
                return JsonResponse({"status": "error-yourself", "message": "Can't message yourself"}, status=400)
            else:
                chat_find = Chat.objects.filter(
                    (models.Q(user_one=request.user) & models.Q(user_two=ad.user)) |
                    (models.Q(user_one=ad.user) & models.Q(user_two=request.user))
                ).first()
                
                if chat_find:
                    redirect_url = f"/accounts/chat/{chat_find.id}/"
                else:
                    new_chat = Chat.objects.create(
                        user_one=request.user,
                        user_two=ad.user
                    )
                    redirect_url = f"/accounts/chat/{new_chat.id}/"

                return JsonResponse({"status": "success", "redirect_url": redirect_url}) 


    # report ajax post
    if request.POST.get("report_type"):
        if not request.user.is_authenticated:
            pass
        else:
            report_type = request.POST.get("report_type")
            description = request.POST.get("description")
            ReportAds.objects.create(
                ad = ad,
                user = request.user,
                report_type = report_type,
                description = description
            )
            print("report saved")
            return JsonResponse({'status__report': "Your report has been successfully submitted. Thank you for your cooperation."})


    # time-ago display (robust)
    time_display = "unknown"
    try:
        ad_date = ad.date
        # if it's a date (no time), convert to datetime at midnight
        if isinstance(ad_date, date) and not isinstance(ad_date, datetime):
            ad_dt = datetime(ad_date.year, ad_date.month, ad_date.day)
        elif isinstance(ad_date, datetime):
            ad_dt = ad_date
        else:
            # fallback try parse string
            ad_dt = datetime.strptime(str(ad_date), '%Y-%m-%d')

        if timezone.is_naive(ad_dt):
            ad_dt = timezone.make_aware(ad_dt)

        diff = timezone.now() - ad_dt
        days = diff.days
        if days == 0:
            time_display = "today"
        elif days == 1:
            time_display = "yesterday"
        elif days < 7:
            time_display = f"{days} days ago"
        elif days < 30:
            weeks = days // 7
            time_display = f"{weeks} week{'s' if weeks > 1 else ''} ago"
        else:
            # months/years approx
            current = timezone.now().date()
            ad_date_only = ad_dt.date()
            years = current.year - ad_date_only.year
            months = current.month - ad_date_only.month
            if current.day < ad_date_only.day:
                months -= 1
            if months < 0:
                years -= 1
                months += 12
            if years > 0:
                time_display = f"{years} year{'s' if years > 1 else ''} ago"
            elif months > 0:
                time_display = f"{months} month{'s' if months > 1 else ''} ago"
            else:
                time_display = f"{days} days ago"
    except Exception:
        time_display = f"unknown"

    context = {"ad": ad, "mapy": mapy, "mapx": mapx, "save": save__index, "time_ago_display": time_display, "comments": comments}

    return render(request, 'main/detail.html', context)


def Rules(request):
    context = {}
    

    return render(request,'main/rules.html',context)

@login_required(login_url='/accounts/signin')
def Bookmarks(request):
    bookmarks = SavedAds.objects.filter(user = request.user)
    context = {"bookmarks":bookmarks}

    return render(request,'profile/bookmarks.html',context)
    