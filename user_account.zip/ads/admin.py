from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Token)
admin.site.register(Ads)


# ! DETAIL ADS ADMIN

admin.site.register(SavedAds)
admin.site.register(RateAds)
admin.site.register(ComeentsAds)
admin.site.register(ReportAds)