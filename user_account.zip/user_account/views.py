from django.shortcuts import render
from user_account.models import CustomUser
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required(login_url='/accounts/signin')
def Profile(request):
    context = {}

    user = CustomUser.objects.filter(id = request.user.id).first()


    # ! CHANGE USER INFORMATION

    if request.POST.get("username") or request.FILES:
        first_name = request.POST.get("name")
        postal = request.POST.get("zip")
        address = request.POST.get("address")
        city = request.POST.get("city")
        state = request.POST.get("state")
        biography = request.POST.get("biography")
        organization = request.POST.get("organization")
        profile = request.FILES.get("profile")

        user.first_name = first_name
        if postal:
            user.postal_code = postal
        user.address = address
        user.city = city
        user.state = state
        user.biography = biography
        user.organization = organization

        # * CHANGE PROFILE PICTURE

        if profile:
            user.profile = profile

        user.save()

        print("User info updated")
        context['success_info'] = "Information updated successfully."

    # ! CHANGE USER PASSWORD

    if request.POST.get("new-password"):
        new_password = request.POST.get("new-password")
        confirm_password = request.POST.get("confirm-password")
        
        if len(new_password) >= 8 :
            if new_password == confirm_password:
                user.set_password(new_password)
                user.save()
                context['success_password'] = "Password changed successfully."
            else:
               context['error_password__same'] = "The passwords are not the same!" 
        else:
            context['error_password__long'] = "Password must be 8 characters long!" 

            

    return render(request,"profile/profile.html",context)
