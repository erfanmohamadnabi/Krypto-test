from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.



# ! COUSTOM USER MODEL

class CustomUser(AbstractUser):
    state = models.CharField(verbose_name='state',max_length=1000,null=True,blank=True)
    city = models.CharField(verbose_name='city',max_length=1000,null=True,blank=True)
    postal_code = models.IntegerField(verbose_name='postal code',null=True,blank=True,default=000000)
    organization = models.CharField(verbose_name='organization',max_length=1000,null=True,blank=True,default='unknown')
    address = models.TextField(verbose_name='address',null=True,blank=True,default='unknown')
    biography = models.TextField(verbose_name='biography',null=True,blank=True,default='unknown')
    profile = models.FileField(verbose_name='profile image',null=True,blank=True,upload_to='profiles/',default='profiles/default.svg')


# ! NOTFICATION MODEL

class Notification(models.Model):
    title = models.CharField(verbose_name='title',max_length=1000)
    message = models.TextField(verbose_name='message')
    created_at = models.DateTimeField(verbose_name='created at',auto_now_add=True)

    def __str__(self):
        return self.message
    
    class Meta:
        verbose_name = 'Notification'
        verbose_name_plural = 'Notifications'