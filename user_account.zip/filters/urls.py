from django.urls import path
from .views import ListView

urlpatterns = [
    path('all-ads', ListView, name='list'),

]
