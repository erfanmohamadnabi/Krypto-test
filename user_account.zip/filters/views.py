from django.shortcuts import render
from ads.models import Ads
# Create your views here.


def ListView(request):
    ads = Ads.objects.all()
    context = {"ads": ads}

    return render(request, "main/filters/list.html", context)