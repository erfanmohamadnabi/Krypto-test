from django import forms
from user_account.models import CustomUser
import re


class SignUp(forms.Form):    
    username = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            "name": "username",
            "maxlength": "200",
            "class": "w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:border-gray-400",
            "id": "username",
            "placeholder": "enter your email",
            "type": "email"
        })
    )

    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            "class": "w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 mt-5",
            "placeholder": "eneter your password"
        })
    )

    
    def clean_password(self):
        p=self.cleaned_data.get("password")
        x=self.cleaned_data.get("password_again")

        if len(p) < 8:
            raise forms.ValidationError("Password must be at least 8 characters long.")

        return p
    
    
    def clean_username(self):
        n = self.cleaned_data.get("username")
        
        # بررسی وجود کاربر با نام کاربری داده شده
        u = CustomUser.objects.filter(username=n)
        if u.exists():
            raise forms.ValidationError("This user already exists.")
    
        # بررسی فرمت ایمیل با استفاده از عبارات منظم
        email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(email_regex, n):
            raise forms.ValidationError("Enter your email correctly.")
    
        return n
    
#____________________________________________________________________________________

class SignIn(forms.Form):    
    username = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            "name": "username",
            "maxlength": "200",
            "class": "w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:border-gray-400",
            "id": "username",
            "placeholder": "enter your email",
            "type": "email"
        })
    )

    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            "class": "w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 mt-5",
            "placeholder": "eneter your password"
        })
    )

    

