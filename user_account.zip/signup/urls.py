from django.contrib import admin
from django.urls import path,include,re_path
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView
from django.views.static import serve 
from .views import Signup,Signin,Signout

urlpatterns = [
    path('accounts/signup', Signup,name='signup'),
    path('accounts/signin', Signin,name='signin'),
    path('accounts/signout', Signout,name='signout')

]

