from django.shortcuts import render
from user_account.models import CustomUser
from .forms import SignUp,SignIn
from django.contrib.auth import authenticate,login,logout
from django.shortcuts import redirect
from .decorators import redirect_if_authenticated

# Create your views here.

@redirect_if_authenticated
def Signup(request):
    frm = SignUp(request.POST or None)
    context = {"frm":frm}

    # * SIGNUP FROM EMAIL


    if request.POST:
        if frm.is_valid():

            data = frm.cleaned_data
            username = data.get("username")
            password = data.get('password')

            new_user = CustomUser.objects.create(
                username = username,
                email = username,
                first_name = "New User",
            )

            new_user.set_password(password)

            new_user.save()

            return redirect("/signin")

    return render(request,'main/signup.html',context)


@redirect_if_authenticated
def Signin(request):
    frm = SignIn(request.POST or None)
    context = {"frm":frm}

    # * SIGNIN FROM EMAIL

    if request.POST:
        if frm.is_valid():

            data  = frm.cleaned_data
            username = data.get("username")
            password = data.get("password")
            U = authenticate(username=username, password=password)
            if U:
                login(request,U)
                return redirect("/account/profile")
            else:
                context["error"] = 'The username or password is incorrect.'


    return render(request,"main/signin.html",context)


def Signout(request):
    logout(request)
    return redirect("/")