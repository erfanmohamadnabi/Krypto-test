import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
# --- ایمپورت‌های وابسته به تنظیمات را فعلاً حذف کنید ---

# 1. تنظیم متغیر محیطی برای تعیین فایل تنظیمات (این باید اولین کاری باشد که انجام می‌شود)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'btc_treff.settings')

# 2. فراخوانی get_asgi_application برای بارگذاری تنظیمات (حالا ایمن است)
django_asgi_app = get_asgi_application()

# --- حالا می‌توانیم ایمپورت‌های وابسته را انجام دهیم ---
from channels.auth import AuthMiddlewareStack
from chat import routing 

# 3. ترکیب Routerها
application = ProtocolTypeRouter({
    # مسیریابی HTTP
    "http": django_asgi_app,
    
    # مسیریابی WebSocket با Middleware احراز هویت
    "websocket": AuthMiddlewareStack(
        URLRouter(
            routing.websocket_urlpatterns
        )
    ),
})
